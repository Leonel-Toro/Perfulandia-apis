package com.example.soporte;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SoporteApplicationTests {

	@Test
	void contextLoads() {
	}

}
